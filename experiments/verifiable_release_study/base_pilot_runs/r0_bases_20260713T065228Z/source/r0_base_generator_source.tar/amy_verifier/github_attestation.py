from __future__ import annotations

import base64
import hashlib
import os
import platform
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Sequence

from .json_tools import bounded_regular_file_read, parse_json_bytes
from .model import VerificationReject


class GitHubGateError(Exception):
    """Base class for the production GitHub/Sigstore release gate."""


class GitHubGateConfigurationError(GitHubGateError):
    """The verifier or release-specific trust policy is not frozen/usable."""


class GitHubGateRejected(GitHubGateError):
    """The supplied artifact/bundle does not satisfy the frozen policy."""

    def __init__(self, code: str, message: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


class GitHubGateToolError(GitHubGateError):
    """The external verifier did not return a trustworthy policy decision."""


@dataclass(frozen=True)
class GitHubAttestationEvidence:
    profile_id: str
    manifest_sha256: str
    bundle_sha256: str
    trusted_root_sha256: str
    predicate_type: str
    certificate: dict[str, Any]
    verified_timestamps: list[dict[str, Any]]
    statement: dict[str, Any]
    gh_version: str
    gh_binary_sha256: str
    gh_command: tuple[str, ...]


Runner = Callable[..., subprocess.CompletedProcess[bytes]]


def _sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _platform_key() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    aliases = {
        "amd64": "x86_64",
        "x64": "x86_64",
        "aarch64": "arm64",
    }
    return f"{system}-{aliases.get(machine, machine)}"


def _require_mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise GitHubGateConfigurationError(f"{label} must be a JSON object")
    return value


def _require_text(mapping: dict[str, Any], key: str, label: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value:
        raise GitHubGateConfigurationError(f"{label}.{key} must be a non-empty string")
    if "TBD-BEFORE-REGISTRATION" in value:
        raise GitHubGateConfigurationError(f"{label}.{key} is not frozen")
    return value


def _require_hex(value: str, lengths: set[int], label: str) -> str:
    if len(value) not in lengths or re.fullmatch(r"[0-9a-f]+", value) is None:
        raise GitHubGateConfigurationError(
            f"{label} must be lowercase hexadecimal with length {sorted(lengths)}"
        )
    return value


def _policy_sections(policy: dict[str, Any]) -> tuple[dict[str, Any], ...]:
    return tuple(
        _require_mapping(policy.get(name), name)
        for name in (
            "tool",
            "subject",
            "identity",
            "trust",
            "statement",
            "provenance",
            "limits",
        )
    )


def load_github_policy(path: Path, *, max_bytes: int = 1024 * 1024) -> tuple[dict[str, Any], bytes]:
    try:
        raw = bounded_regular_file_read(path, max_bytes, check="bounded_input")
        value = parse_json_bytes(
            raw,
            max_depth=32,
            reject_duplicate_keys=True,
            failure_check="bounded_input",
            invalid_reason="JSON_INVALID",
            duplicate_reason="DUPLICATE_JSON_KEY",
        )
    except VerificationReject as exc:
        raise GitHubGateConfigurationError(exc.message) from exc
    if not isinstance(value, dict):
        raise GitHubGateConfigurationError("GitHub attestation policy must be a JSON object")
    _policy_sections(value)
    return value, raw


def extract_untrusted_predicate_type(bundle_raw: bytes, *, max_depth: int, max_statement: int) -> str:
    """Extract only the candidate type needed by gh; nothing returned here is trusted."""

    try:
        bundle = parse_json_bytes(
            bundle_raw,
            max_depth=max_depth,
            reject_duplicate_keys=True,
            failure_check="attestation_structure",
            invalid_reason="ATTESTATION_INVALID",
            duplicate_reason="ATTESTATION_INVALID",
        )
    except VerificationReject as exc:
        raise GitHubGateRejected(exc.reason, exc.message, exc.details) from exc
    if not isinstance(bundle, dict):
        raise GitHubGateRejected("ATTESTATION_INVALID", "Sigstore bundle is not an object")
    envelope = bundle.get("dsseEnvelope")
    if not isinstance(envelope, dict):
        raise GitHubGateRejected("ATTESTATION_INVALID", "Sigstore bundle has no DSSE envelope")
    encoded = envelope.get("payload")
    if not isinstance(encoded, str):
        raise GitHubGateRejected("ATTESTATION_INVALID", "DSSE payload is not base64 text")
    try:
        payload = base64.b64decode(encoded, validate=True)
    except Exception as exc:
        raise GitHubGateRejected("ATTESTATION_INVALID", "DSSE payload is not valid base64") from exc
    if len(payload) > max_statement:
        raise GitHubGateRejected(
            "RESOURCE_LIMIT",
            "DSSE Statement exceeds the byte limit",
            {"observed_bytes": len(payload), "max_bytes": max_statement},
        )
    try:
        statement = parse_json_bytes(
            payload,
            max_depth=max_depth,
            reject_duplicate_keys=True,
            failure_check="attestation_structure",
            invalid_reason="ATTESTATION_INVALID",
            duplicate_reason="ATTESTATION_INVALID",
        )
    except VerificationReject as exc:
        raise GitHubGateRejected(exc.reason, exc.message, exc.details) from exc
    predicate_type = statement.get("predicateType") if isinstance(statement, dict) else None
    if (
        not isinstance(predicate_type, str)
        or len(predicate_type) > 2048
        or re.fullmatch(r"https://[^\s\x00-\x1f\x7f]+", predicate_type) is None
    ):
        raise GitHubGateRejected(
            "ATTESTATION_INVALID", "candidate predicateType is not a bounded HTTPS URI"
        )
    return predicate_type


def build_gh_verify_command(
    gh_path: Path,
    manifest_path: Path,
    bundle_path: Path,
    trusted_root_path: Path,
    policy: dict[str, Any],
    predicate_type: str,
) -> tuple[str, ...]:
    _, subject, identity, _, _, _, _ = _policy_sections(policy)
    if _require_text(subject, "digest_algorithm", "subject") != "sha256":
        raise GitHubGateConfigurationError("production subject digest must be sha256")
    command = (
        str(gh_path),
        "attestation",
        "verify",
        str(manifest_path),
        "--digest-alg",
        "sha256",
        "--bundle",
        str(bundle_path),
        "--custom-trusted-root",
        str(trusted_root_path),
        "--repo",
        _require_text(identity, "repository", "identity"),
        "--cert-identity",
        _require_text(identity, "certificate_identity", "identity"),
        "--cert-oidc-issuer",
        _require_text(identity, "oidc_issuer", "identity"),
        "--signer-digest",
        _require_hex(
            _require_text(identity, "signer_digest", "identity"), {40, 64}, "identity.signer_digest"
        ),
        "--source-digest",
        _require_hex(
            _require_text(identity, "source_digest", "identity"), {40, 64}, "identity.source_digest"
        ),
        "--source-ref",
        _require_text(identity, "source_ref", "identity"),
        "--predicate-type",
        predicate_type,
        "--deny-self-hosted-runners",
        "--format",
        "json",
    )
    return command


def _material_map(predicate: dict[str, Any]) -> dict[str, dict[str, str]]:
    definition = predicate.get("buildDefinition")
    dependencies = definition.get("resolvedDependencies") if isinstance(definition, dict) else None
    if not isinstance(dependencies, list):
        raise GitHubGateRejected("PROVENANCE_INVALID", "resolvedDependencies is missing")
    found: dict[str, dict[str, str]] = {}
    for item in dependencies:
        if not isinstance(item, dict) or not isinstance(item.get("uri"), str):
            raise GitHubGateRejected("PROVENANCE_INVALID", "a resolved dependency is malformed")
        uri = item["uri"]
        digest = item.get("digest")
        if uri in found or not isinstance(digest, dict) or not all(
            isinstance(key, str) and isinstance(value, str) for key, value in digest.items()
        ):
            raise GitHubGateRejected("PROVENANCE_INVALID", "resolved dependencies are ambiguous")
        found[uri] = digest
    return found


def _enforce_p3(statement: dict[str, Any], policy: dict[str, Any]) -> None:
    _, _, identity, _, statement_policy, provenance, _ = _policy_sections(policy)
    expected_type = _require_text(statement_policy, "p3_predicate_type", "statement")
    if statement.get("predicateType") != expected_type:
        raise GitHubGateRejected("PREDICATE_TYPE_UNSUPPORTED", "P3 predicate type mismatch")
    predicate = statement.get("predicate")
    if not isinstance(predicate, dict):
        raise GitHubGateRejected("PROVENANCE_INVALID", "authenticated predicate is not an object")
    definition = predicate.get("buildDefinition")
    details = predicate.get("runDetails")
    if not isinstance(definition, dict) or not isinstance(details, dict):
        raise GitHubGateRejected("PROVENANCE_INVALID", "SLSA provenance structure is incomplete")
    if definition.get("buildType") != _require_text(provenance, "build_type", "provenance"):
        raise GitHubGateRejected("PROVENANCE_INVALID", "build type is not authorized")
    external = definition.get("externalParameters")
    source = external.get("source") if isinstance(external, dict) else None
    workflow = external.get("workflow") if isinstance(external, dict) else None
    expected_source = {
        "repository": _require_text(provenance, "source_repository_uri", "provenance"),
        "revision": _require_hex(
            _require_text(provenance, "source_revision", "provenance"),
            {40, 64},
            "provenance.source_revision",
        ),
        "ref": _require_text(provenance, "source_ref", "provenance"),
        "dirty": False,
    }
    if source != expected_source:
        code = "DIRTY_BUILD" if isinstance(source, dict) and source.get("dirty") is not False else "SOURCE_MISMATCH"
        raise GitHubGateRejected(code, "authenticated source snapshot policy mismatch")
    expected_workflow = {
        "repository": expected_source["repository"],
        "path": _require_text(provenance, "workflow_path", "provenance"),
        "ref": _require_text(identity, "source_ref", "identity"),
    }
    if workflow != expected_workflow:
        raise GitHubGateRejected("BUILDER_UNAUTHORIZED", "authenticated workflow policy mismatch")
    builder = details.get("builder")
    if not isinstance(builder, dict) or builder.get("id") != _require_text(
        provenance, "builder_id", "provenance"
    ):
        raise GitHubGateRejected("BUILDER_UNAUTHORIZED", "authenticated builder policy mismatch")

    materials = provenance.get("materials")
    if not isinstance(materials, list) or not materials:
        raise GitHubGateConfigurationError("provenance.materials must be a non-empty array")
    observed = _material_map(predicate)
    source_dependency_uri = f"git+{expected_source['repository']}@{expected_source['ref']}"
    if observed.get(source_dependency_uri) != {"gitCommit": expected_source["revision"]}:
        raise GitHubGateRejected(
            "SOURCE_MISMATCH", "resolved source dependency does not match the frozen revision"
        )
    for required in materials:
        required = _require_mapping(required, "provenance.materials[]")
        uri = _require_text(required, "uri", "provenance.materials[]")
        algorithm = _require_text(required, "algorithm", "provenance.materials[]")
        digest = _require_hex(
            _require_text(required, "digest", "provenance.materials[]"),
            {40, 64, 128},
            f"material {uri}",
        )
        if observed.get(uri) != {algorithm: digest}:
            raise GitHubGateRejected("MATERIAL_MISMATCH", f"required material mismatch: {uri}")


def validate_verified_output(
    output: Any,
    *,
    profile_id: str,
    manifest_raw: bytes,
    policy: dict[str, Any],
    predicate_type: str,
) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    _, subject_policy, identity, trust, statement_policy, _, _ = _policy_sections(policy)
    if not isinstance(output, list) or len(output) != 1 or not isinstance(output[0], dict):
        raise GitHubGateRejected(
            "ATTESTATION_AMBIGUOUS", "exactly one verified attestation is required"
        )
    result = output[0].get("verificationResult")
    if not isinstance(result, dict):
        raise GitHubGateToolError("gh success output has no verificationResult")
    attestation = output[0].get("attestation")
    bundle = attestation.get("bundle") if isinstance(attestation, dict) else None
    allowed_bundle_types = trust.get("allowed_bundle_media_types")
    if (
        not isinstance(bundle, dict)
        or not isinstance(allowed_bundle_types, list)
        or bundle.get("mediaType") not in allowed_bundle_types
    ):
        raise GitHubGateRejected("ATTESTATION_INVALID", "Sigstore bundle media type is not frozen")
    allowed_result_types = trust.get("allowed_verification_result_media_types")
    if not isinstance(allowed_result_types, list) or result.get("mediaType") not in allowed_result_types:
        raise GitHubGateRejected("ATTESTATION_INVALID", "verification-result media type is not frozen")
    signature = result.get("signature")
    certificate = signature.get("certificate") if isinstance(signature, dict) else None
    if not isinstance(certificate, dict):
        raise GitHubGateToolError("gh success output has no parsed certificate")
    expected_certificate = {
        "issuer": _require_text(identity, "oidc_issuer", "identity"),
        "subjectAlternativeName": _require_text(identity, "certificate_identity", "identity"),
        "sourceRepositoryURI": _require_text(identity, "repository_uri", "identity"),
        "sourceRepositoryOwnerURI": _require_text(identity, "repository_owner_uri", "identity"),
        "buildSignerDigest": _require_text(identity, "signer_digest", "identity"),
        "sourceRepositoryDigest": _require_text(identity, "source_digest", "identity"),
        "sourceRepositoryRef": _require_text(identity, "source_ref", "identity"),
        "runnerEnvironment": "github-hosted",
        "githubWorkflowTrigger": _require_text(identity, "event_name", "identity"),
        "sourceRepositoryVisibilityAtSigning": _require_text(identity, "visibility", "identity"),
    }
    for key, expected in expected_certificate.items():
        if certificate.get(key) != expected:
            raise GitHubGateRejected("SIGNER_UNAUTHORIZED", f"certificate field mismatch: {key}")
    issuer_dn = certificate.get("certificateIssuer")
    required_org = _require_text(trust, "certificate_issuer_organization", "trust")
    if not isinstance(issuer_dn, str) or not (
        issuer_dn == f"O={required_org}" or issuer_dn.endswith(f",O={required_org}")
    ):
        raise GitHubGateRejected("SIGNER_UNAUTHORIZED", "certificate authority profile mismatch")

    timestamps = result.get("verifiedTimestamps")
    if not isinstance(timestamps, list) or not all(isinstance(item, dict) for item in timestamps):
        raise GitHubGateToolError("gh success output has malformed verifiedTimestamps")
    required_type = _require_text(trust, "required_timestamp_type", "trust")
    required_uri = _require_text(trust, "required_timestamp_uri", "trust")
    if not any(item.get("type") == required_type and item.get("uri") == required_uri for item in timestamps):
        raise GitHubGateRejected("TRANSPARENCY_INVALID", "required public transparency evidence is absent")

    statement = result.get("statement")
    if not isinstance(statement, dict):
        raise GitHubGateToolError("gh success output has no authenticated Statement")
    if statement.get("_type") != _require_text(statement_policy, "type", "statement"):
        raise GitHubGateRejected("ATTESTATION_INVALID", "authenticated payload is not Statement v1")
    if statement.get("predicateType") != predicate_type:
        raise GitHubGateRejected("ATTESTATION_INVALID", "verified predicate type differs from requested type")
    subjects = statement.get("subject")
    digest = _sha256(manifest_raw)
    expected_subject = {
        "name": _require_text(subject_policy, "name", "subject"),
        "digest": {"sha256": digest},
    }
    allow_additional = subject_policy.get("allow_additional_subjects")
    if not isinstance(allow_additional, bool):
        raise GitHubGateConfigurationError("subject.allow_additional_subjects must be boolean")
    if not isinstance(subjects, list):
        raise GitHubGateRejected("SUBJECT_MISMATCH", "Statement subject is not an array")
    if (allow_additional and subjects.count(expected_subject) != 1) or (
        not allow_additional and subjects != [expected_subject]
    ):
        raise GitHubGateRejected("SUBJECT_MISMATCH", "Statement does not bind the exact manifest bytes")
    if profile_id == "P3":
        _enforce_p3(statement, policy)
    return statement, certificate, timestamps


def _write_private(path: Path, raw: bytes, *, mode: int = 0o600) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        view = memoryview(raw)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("short write while creating private verifier input")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _resolve_gh(gh_binary: str) -> Path:
    candidate = shutil.which(gh_binary) if os.sep not in gh_binary else gh_binary
    if not candidate:
        raise GitHubGateConfigurationError(f"GitHub CLI executable not found: {gh_binary}")
    path = Path(candidate).resolve()
    if not path.is_file():
        raise GitHubGateConfigurationError(f"GitHub CLI path is not a regular file: {path}")
    return path


def _run(
    runner: Runner,
    command: Sequence[str],
    *,
    timeout: int,
    env: dict[str, str],
) -> subprocess.CompletedProcess[bytes]:
    try:
        return runner(
            list(command),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=False,
            check=False,
            timeout=timeout,
            env=env,
        )
    except subprocess.TimeoutExpired as exc:
        raise GitHubGateToolError(f"GitHub CLI exceeded the {timeout}s timeout") from exc
    except OSError as exc:
        raise GitHubGateToolError(f"GitHub CLI could not be executed: {exc}") from exc


def verify_github_manifest_attestation(
    manifest_path: Path,
    bundle_path: Path,
    trusted_root_path: Path,
    *,
    profile_id: str,
    policy: dict[str, Any],
    gh_binary: str = "gh",
    runner: Runner = subprocess.run,
) -> GitHubAttestationEvidence:
    if profile_id not in {"P2", "P3"}:
        raise GitHubGateConfigurationError("GitHub attestation gate supports only P2 or P3")
    tool, _, _, trust, statement_policy, _, limits = _policy_sections(policy)
    try:
        manifest_raw = bounded_regular_file_read(
            manifest_path, int(limits["manifest_max_bytes"]), check="bounded_input"
        )
        bundle_raw = bounded_regular_file_read(
            bundle_path, int(limits["attestation_max_bytes"]), check="bounded_input"
        )
        root_raw = bounded_regular_file_read(
            trusted_root_path, int(limits["trusted_root_max_bytes"]), check="bounded_input"
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise GitHubGateConfigurationError("production byte limits are incomplete") from exc
    except VerificationReject as exc:
        raise GitHubGateRejected(exc.reason, exc.message, exc.details) from exc

    trusted_root_sha256 = _sha256(root_raw)
    expected_root = _require_hex(
        _require_text(trust, "trusted_root_sha256", "trust"), {64}, "trust.trusted_root_sha256"
    )
    if trusted_root_sha256 != expected_root:
        raise GitHubGateRejected("TRUST_ROOT_MISMATCH", "archived trusted-root digest mismatch")

    if profile_id == "P3":
        predicate_type = _require_text(statement_policy, "p3_predicate_type", "statement")
    else:
        predicate_type = extract_untrusted_predicate_type(
            bundle_raw,
            max_depth=int(limits["json_max_depth"]),
            max_statement=int(limits["dsse_statement_max_bytes"]),
        )

    gh_source_path = _resolve_gh(gh_binary)
    binary_max_bytes = tool.get("binary_max_bytes")
    if (
        not isinstance(binary_max_bytes, int)
        or isinstance(binary_max_bytes, bool)
        or not 1 <= binary_max_bytes <= 512 * 1024 * 1024
    ):
        raise GitHubGateConfigurationError(
            "tool.binary_max_bytes must be an integer from 1 to 536870912"
        )
    try:
        gh_binary_raw = bounded_regular_file_read(
            gh_source_path, binary_max_bytes, check="bounded_input"
        )
    except VerificationReject as exc:
        raise GitHubGateConfigurationError(f"cannot freeze GitHub CLI bytes: {exc.message}") from exc
    gh_binary_sha256 = _sha256(gh_binary_raw)
    binary_hashes = _require_mapping(
        tool.get("binary_sha256_by_platform"), "tool.binary_sha256_by_platform"
    )
    platform_key = _platform_key()
    expected_binary = _require_hex(
        _require_text(binary_hashes, platform_key, "tool.binary_sha256_by_platform"),
        {64},
        f"tool.binary_sha256_by_platform.{platform_key}",
    )
    if gh_binary_sha256 != expected_binary:
        raise GitHubGateConfigurationError("GitHub CLI binary hash differs from the frozen tool")

    timeout = tool.get("timeout_seconds")
    if not isinstance(timeout, int) or isinstance(timeout, bool) or not 1 <= timeout <= 600:
        raise GitHubGateConfigurationError("tool.timeout_seconds must be an integer from 1 to 600")
    expected_version = _require_text(tool, "version", "tool")
    with tempfile.TemporaryDirectory(prefix="amy-gh-attestation-") as temporary:
        temp_root = Path(temporary)
        exact_gh = temp_root / "gh"
        exact_manifest = temp_root / "MANIFEST.jcs.json"
        exact_bundle = temp_root / "attestation.sigstore.json"
        exact_trust = temp_root / "trusted_root.jsonl"
        _write_private(exact_gh, gh_binary_raw, mode=0o700)
        _write_private(exact_manifest, manifest_raw)
        _write_private(exact_bundle, bundle_raw)
        _write_private(exact_trust, root_raw)

        env = dict(os.environ)
        env.pop("GH_TOKEN", None)
        env.pop("GITHUB_TOKEN", None)
        env.update(
            {
                "GH_CONFIG_DIR": str(temp_root / "gh-config"),
                "GH_NO_UPDATE_NOTIFIER": "1",
                "NO_COLOR": "1",
            }
        )
        version_result = _run(runner, (str(exact_gh), "--version"), timeout=10, env=env)
        if version_result.returncode != 0:
            raise GitHubGateToolError("GitHub CLI version check failed")
        first_line = version_result.stdout.decode("utf-8", errors="replace").splitlines()[:1]
        match = re.fullmatch(
            r"gh version ([0-9]+\.[0-9]+\.[0-9]+)(?: .*)?",
            first_line[0] if first_line else "",
        )
        if match is None or match.group(1) != expected_version:
            raise GitHubGateConfigurationError("GitHub CLI version differs from the frozen tool")
        command = build_gh_verify_command(
            exact_gh, exact_manifest, exact_bundle, exact_trust, policy, predicate_type
        )
        completed = _run(runner, command, timeout=timeout, env=env)
        normalized_command = tuple(
            {
                str(exact_gh): "gh",
                str(exact_manifest): "MANIFEST.jcs.json",
                str(exact_bundle): "attestation.sigstore.json",
                str(exact_trust): "trusted_root.jsonl",
            }.get(argument, argument)
            for argument in command
        )
    stderr = completed.stderr.decode("utf-8", errors="replace")[-8192:]
    if completed.returncode != 0:
        raise GitHubGateRejected(
            "GH_VERIFICATION_FAILED",
            "GitHub/Sigstore verification rejected the manifest or attestation",
            {"exit_code": completed.returncode, "stderr_tail": stderr},
        )
    max_output = int(limits.get("gh_output_max_bytes", 32 * 1024 * 1024))
    if len(completed.stdout) > max_output:
        raise GitHubGateToolError("GitHub CLI JSON output exceeded the frozen byte limit")
    try:
        output = parse_json_bytes(
            completed.stdout,
            max_depth=int(limits["json_max_depth"]),
            reject_duplicate_keys=True,
            failure_check="attestation_structure",
            invalid_reason="ATTESTATION_INVALID",
            duplicate_reason="ATTESTATION_INVALID",
        )
    except VerificationReject as exc:
        raise GitHubGateToolError(f"GitHub CLI returned invalid JSON: {exc.message}") from exc
    statement, certificate, timestamps = validate_verified_output(
        output,
        profile_id=profile_id,
        manifest_raw=manifest_raw,
        policy=policy,
        predicate_type=predicate_type,
    )
    return GitHubAttestationEvidence(
        profile_id=profile_id,
        manifest_sha256=_sha256(manifest_raw),
        bundle_sha256=_sha256(bundle_raw),
        trusted_root_sha256=trusted_root_sha256,
        predicate_type=predicate_type,
        certificate=certificate,
        verified_timestamps=timestamps,
        statement=statement,
        gh_version=expected_version,
        gh_binary_sha256=gh_binary_sha256,
        gh_command=normalized_command,
    )


def evidence_to_json(evidence: GitHubAttestationEvidence) -> dict[str, Any]:
    return {
        "decision": "ACCEPT",
        "profile_id": evidence.profile_id,
        "manifest_sha256": evidence.manifest_sha256,
        "bundle_sha256": evidence.bundle_sha256,
        "trusted_root_sha256": evidence.trusted_root_sha256,
        "predicate_type": evidence.predicate_type,
        "certificate": evidence.certificate,
        "verified_timestamps": evidence.verified_timestamps,
        "statement": evidence.statement,
        "tool": {
            "name": "gh",
            "version": evidence.gh_version,
            "binary_sha256": evidence.gh_binary_sha256,
            "argv": list(evidence.gh_command),
        },
    }
