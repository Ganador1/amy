print('deterministic paper fixture')
