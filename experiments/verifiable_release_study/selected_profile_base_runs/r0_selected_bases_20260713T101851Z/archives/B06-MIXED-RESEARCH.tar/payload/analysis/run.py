print('mixed research fixture')
